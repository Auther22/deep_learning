import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
import copy
import json
import os
import cv2
import argparse
import pandas as pd

def get_args():
    parser = argparse.ArgumentParser(description='load json and bmp image')
    parser.add_argument('--ddh_path', default='dataset/DDH/')
    parser.add_argument('--normal_path', default='dataset/normal')
    parser.add_argument('--json_path', default='labels_new')
    parser.add_argument('--img_path', default='images')
    return parser.parse_args()


def plot_sample(x, y, axis):
    """
    :param x: (9216,)
    :param y: (15,2)
    :param axis:
    :return:
    """
    img = x.reshape(256, 256)
    axis.imshow(img, cmap='gray')
    axis.scatter(y[:, 0], y[:, 1], marker='x', s=10)
    
def plot_demo(X, y):
    fig = plt.figure(figsize=(6, 6))
    fig.subplots_adjust(
        left=0, right=1, bottom=0, top=1, hspace=0.05, wspace=0.05)

    for i in range(16):
        ax = fig.add_subplot(4, 4, i + 1, xticks=[], yticks=[])
        plot_sample(X[i], y[i], ax)
    plt.show()
    
class KFDataset(Dataset):
    def __init__(self, config, X=None, gts=None):
        """
        :param X: (N,96*96)
        :param gts: (N,15,2)
        """
        self.__X = X
        self.__gts = gts
        self.__sigma = config['sigma']
        self.__debug_vis = config['debug_vis']
        self.__is_test = config['is_test']
        # self.__ftrain = config['ftrain']
        # self.load(self.__ftrain)
        self.ddh_imgs = []
        self.normal_imgs = []
        self.images = []   # ddh_imgs和normal_imgs的并集，同时用于训练点的位置
        
        self.ddh_labels = []
        self.normal_labels = []
        self.json = []  # ddh_labels和normal_labels的并集，同时用于训练点的位置

        self.tear_dropR = []
        self.tear_dropL = []
        self.tiR = []
        self.tiL = []
        self.FHR = []
        self.FHL = []
        self.tonnisR1 = []
        self.tonnisR2 = []
        self.tonnisL1 = []
        self.tonnisL2 = []
        
    def load_data(self):    # 先把image和json文件导入
        print('begin to load data\n')
        args = get_args()
        label_path = os.path.join(args.ddh_path, args.json_path)
        img_path = os.path.join(args.ddh_path, args.img_path)
        for root, dirs, files in os.walk(label_path):
            for file in files:
                with open(os.path.join(label_path, file)) as f:
                    data = json.load(f)
                    self.ddh_labels.append(data)
                    temp_path = data.get('imagePath')
                    if '\\' in temp_path:
                        temp_path = temp_path.split('\\')[-1]
                    elif '/' in temp_path:
                        temp_path = temp_path.split('/')[-1]
                    tar_img = os.path.join(img_path, temp_path)
                    img = cv2.imread(tar_img, cv2.IMREAD_GRAYSCALE)
                    if img is None:
                        print(data.get('imagePath'))
                        print(tar_img)
                        print(file)
                        print(temp_path)
                        exit(-1)
                    img1 = cv2.resize(img, (256, 256))
                    img2 = img1.flatten()
                    self.ddh_imgs.append(img2)

        normal_path = os.path.join(args.normal_path, args.json_path)
        img_path = os.path.join(args.normal_path, args.img_path)
        for root, dirs, files in os.walk(normal_path):
            for file in files:
                with open(os.path.join(normal_path, file)) as f:
                    data = json.load(f)
                    self.normal_labels.append(data)
                    temp_path = data.get('imagePath')
                    if '\\' in temp_path:
                        temp_path = temp_path.split('\\')[-1]
                    elif '/' in temp_path:
                        temp_path = temp_path.split('/')[-1]
                    tar_img = os.path.join(img_path, temp_path)
                    img = cv2.imread(tar_img, cv2.IMREAD_GRAYSCALE)  #彩色图片按灰度图片读入
                    if img is None:
                        print(data.get('imagePath'))
                        print(tar_img)
                        print(file)
                        print(temp_path)
                        exit(-1)
                    img1 = cv2.resize(img, (256, 256))
                    img2 = img1.flatten()
                    self.normal_imgs.append(img2)
        assert len(self.ddh_imgs) != 0 and len(self.normal_imgs) != 0
        assert len(self.ddh_labels) == len(self.ddh_imgs)
        assert len(self.normal_imgs) == len(self.normal_labels)
        print('have successfully loaded ' + str(len(self.ddh_labels)) + ' ddh ')
        print('have successfully loaded ' + str(len(self.normal_labels)) + ' normal ')
    
    def load_json_data(self):   # 将导入的json文件进行处理，将各个点的数据放到列表中
        test = np.zeros(10)
        bias = 0.25     # 缩放因子
        self.json = self.ddh_labels + self.normal_labels
        self.images = self.ddh_imgs + self.normal_imgs
        for temp_json in self.json:
            for json_data in temp_json.get('shapes'):
                label = json_data.get('label')
                if label == 'TeardropR':
                    self.tear_dropR.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[1] += 1
                elif label == 'TeardropL':
                    self.tear_dropL.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[2] += 1
                elif label == 'TiR':
                    self.tiR.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[3] += 1
                elif label == 'TiL':
                    self.tiL.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[4] += 1
                elif label == 'FHR':
                    self.FHR.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[5] += 1
                elif label == 'FHL':
                    self.FHL.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[6] += 1
                elif label == 'tonnisR1':
                    self.tonnisR1.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[7] += 1
                elif label == 'tonnisR2':
                    self.tonnisR2.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[8] += 1
                elif label == 'tonnisL1':
                    self.tonnisL1.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[9] += 1
                elif label == 'tonnisL2':
                    self.tonnisL2.append([json_data.get('points')[0][0]*bias,json_data.get('points')[0][1]*bias])
                    test[0] += 1
        length = test[0]
        for num in test:
            assert num == length

    def load(self, cols=None):  # 将加载到列表中的数据进行导入
        """
        :param fname:
        :param test:
        :param cols:
        :return: X (N,256*256) Y (N,10,2)
        """
        test = self.__is_test
        X = self.images
        # x_list = [item.tolist() for item in X]
        X = np.array(X)    # X中保存图像灰度矩阵数据
        X = X.astype(np.float32)
        # X = X / 255.  # scale pixel values to [0, 1]
        gts = np.concatenate((self.tear_dropR,self.tear_dropL,self.tiR,self.tiL,self.FHR,
                                 self.FHL,self.tonnisR1,self.tonnisR2,self.tonnisL1,self.tonnisL2),axis=1)
        if not test:  # only FTRAIN has any target columns
            gts = gts.reshape((gts.shape[0], -1, 2))
            gts = gts.astype(np.float32)
        else: # 测试集
            gts = np.arange(1, len(gts) + 1)
            # gts = gts  # dataframe.values获取的是dataframe中的数据,形式变为数组array
        self.__X = X
        self.__gts = gts
        print('load data finish\n')
        return X, gts

    def __len__(self):
        return len(self.__X)

    def __getitem__(self, item):    # 某一个图片的gt
        H, W = 256, 256
        x = self.__X[item]
        gt = self.__gts[item]

        if self.__is_test:
            x = x.reshape((1, 256, 256)).astype(np.float32)
            x = x / 255.
            return x, gt  # 返回图像以及其id

        heatmaps = self._putGaussianMaps(gt, H, W, 1, self.__sigma)

        if self.__debug_vis == True:
            for i in range(heatmaps.shape[0]):
                img = copy.deepcopy(x).astype(np.uint8).reshape((H, W))
                self.visualize_heatmap_target(img, copy.deepcopy(heatmaps[i]), 1, i)

        x = x.reshape((1, 256, 256)).astype(np.float32)
        x = x / 255.
        heatmaps = heatmaps.astype(np.float32)
        return x, heatmaps, gt

    def _putGaussianMap(self, center, visible_flag, crop_size_y, crop_size_x, stride, sigma):
        """
        根据一个中心点,生成一个heatmap
        :param center:
        :return:
        """
        grid_y = int(crop_size_y / stride)
        grid_x = int(crop_size_x / stride)
        if not visible_flag:
            return np.zeros((grid_y, grid_x))
        start = stride / 2.0 - 0.5
        y_range = [i for i in range(int(grid_y))]
        x_range = [i for i in range(int(grid_x))]
        xx, yy = np.meshgrid(x_range, y_range)
        xx = xx * stride + start
        yy = yy * stride + start
        d2 = (xx - center[0]) ** 2 + (yy - center[1]) ** 2
        exponent = d2 / 2.0 / sigma / sigma
        heatmap = np.exp(-exponent)
        return heatmap

    def _putGaussianMaps(self, keypoints, crop_size_y, crop_size_x, stride, sigma):
        """
        :param keypoints: (10,2)
        :param crop_size_y: int
        :param crop_size_x: int
        :param stride: int
        :param sigma: float
        :return:
        """
        all_keypoints = keypoints
        point_num = all_keypoints.shape[0]  # 点的个数
        heatmaps_this_img = []
        for k in range(point_num):
            flag = ~np.isnan(all_keypoints[k, 0])
            heatmap = self._putGaussianMap(all_keypoints[k], flag, crop_size_y, crop_size_x, stride, sigma)
            heatmap = heatmap[np.newaxis, ...]
            heatmaps_this_img.append(heatmap)
        heatmaps_this_img = np.concatenate(heatmaps_this_img,
                                           axis=0)  # (num_joint,crop_size_y/stride,crop_size_x/stride)
        return heatmaps_this_img

    def visualize_heatmap_target(self, oriImg, heatmap, stride, i):
        plt.imshow(oriImg)
        plt.imshow(heatmap, alpha=.5)
        plt.savefig('images/heatmaps/'+str(i)+'.png')
        plt.clf()
        
if __name__ == '__main__':
    from train import config   
    dataset = KFDataset(config)
    dataset.load_data()
    dataset.load_json_data()
    dataset.load()
    dataLoader = DataLoader(dataset=dataset, batch_size=36, shuffle=False)
    for i, (x, y, gt) in enumerate(dataLoader):
        print(x.size())
        print(y.size())
        print(gt.size())