# coding=utf-8
import torch
from torch.autograd import Variable
from torch.backends import cudnn
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
import pprint
from data_loader import KFDataset
from models import KFSGNet

config = dict()
config['lr'] = 0.000001
config['momentum'] = 0.9
config['weight_decay'] = 1e-4
config['start_epoch'] = 0
config['epoch_num'] = 40
config['batch_size'] = 26
config['sigma'] = 5.
config['debug_vis'] = False  # 是否可视化heatmaps
# config['is_test'] = False
config['is_test'] = True
config['save_freq'] = 20    # 每20epoch保存一次
config['checkout'] = 'dataset/weight/epoch_39_model.pt'         # dataset/weight/epoch_199_model.pt
# config['eval_freq'] = 5
config['debug'] = False
config['featurename2id'] = {
    'tear_dropR_x': 0,
    'tear_dropR_y': 1,
    'tear_dropL_x': 2,
    'tear_dropL_y': 3,
    'tiR_x': 4,
    'tiR_y': 5,
    'tiL_x': 6,
    'tiL_y': 7,
    'FHR_x': 8,
    'FHR_y': 9,
    'FHL_x': 10,
    'FHL_y': 11,
    'tonnisR1_x': 12,
    'tonnisR1_y': 13,
    'tonnisR2_x': 14,
    'tonnisR2_y': 15,
    'tonnisL1_x': 16,
    'tonnisL1_y': 17,
    'tonnisL2_x': 18,
    'tonnisL2_y': 19,
}


def get_peak_points(heatmaps):
    """

    :param heatmaps: numpy array (N,10,256,256)
    :return:numpy array (N,10,2)
    """
    N, C, H, W = heatmaps.shape
    all_peak_points = []
    for i in range(N):
        peak_points = []
        for j in range(C):
            yy, xx = np.where(heatmaps[i, j] == heatmaps[i, j].max())
            y = yy[0]
            x = xx[0]
            peak_points.append([x, y])
        all_peak_points.append(peak_points)
    all_peak_points = np.array(all_peak_points)
    return all_peak_points


def get_mse(pred_points, gts, indices_valid=None):
    """

    :param pred_points: numpy (N,10,2)
    :param gts: numpy (N,10,2)
    :return:
    """
    pred_points = pred_points[indices_valid[0], indices_valid[1], :]
    gts = gts[indices_valid[0], indices_valid[1], :]
    pred_points = Variable(torch.from_numpy(pred_points).float(), requires_grad=False)
    gts = Variable(torch.from_numpy(gts).float(), requires_grad=False)
    criterion = nn.MSELoss()
    loss = criterion(pred_points, gts)
    return loss


def calculate_mask(heatmaps_target):
    """

    :param heatmaps_target: Variable (N,10,256,256)
    :return: Variable (N,10,256,256)
    """
    N, C, _, _ = heatmaps_targets.size()
    N_idx = []
    C_idx = []
    for n in range(N):
        for c in range(C):
            max_v = heatmaps_targets[n, c, :, :].max().item()
            if max_v != 0.0:
                N_idx.append(n)
                C_idx.append(c)
    mask = Variable(torch.zeros(heatmaps_targets.size()))
    mask[N_idx, C_idx, :, :] = 1.
    mask = mask.float().cuda()
    return mask, [N_idx, C_idx]


if __name__ == '__main__':
    pprint.pprint(config)
    torch.manual_seed(0)
    cudnn.benchmark = True
    net = KFSGNet()
    net.float().cuda()
    net.train()
    criterion = nn.MSELoss()
    # optimizer = optim.SGD(net.parameters(), lr=config['lr'], momentum=config['momentum'] , weight_decay=config['weight_decay'])
    optimizer = optim.Adam(net.parameters(), lr=config['lr'])
    trainDataset = KFDataset(config)
    trainDataset.load_data()
    trainDataset.load_json_data()
    trainDataset.load()
    trainDataLoader = DataLoader(trainDataset, config['batch_size'], True)
    sample_num = len(trainDataset)

    if (config['checkout'] != ''):
        net.load_state_dict(torch.load(config['checkout']))

    for epoch in range(config['start_epoch'], config['epoch_num'] + config['start_epoch']):
        running_loss = 0.0
        for i, (inputs, heatmaps_targets, gts) in enumerate(trainDataLoader):
            inputs = Variable(inputs).cuda()
            heatmaps_targets = Variable(heatmaps_targets).cuda()
            mask, indices_valid = calculate_mask(heatmaps_targets)

            optimizer.zero_grad()
            print(inputs.size())
            outputs = net(inputs)
            outputs = outputs * mask
            heatmaps_targets = heatmaps_targets * mask
            loss = criterion(outputs, heatmaps_targets)
            loss.backward()
            optimizer.step()

            # 统计最大值与最小值
            v_max = torch.max(outputs)
            v_min = torch.min(outputs)

            # 评估
            all_peak_points = get_peak_points(heatmaps_targets.cpu().data.numpy())
            loss_coor = get_mse(all_peak_points, gts.numpy(), indices_valid)

            print('[ Epoch {:005d} -> {:005d} / {} ] loss : {:15} loss_coor : {:15} max : {:10} min : {}'.format(
                epoch, i * config['batch_size'],
                sample_num, loss.item(), loss_coor.item(), v_max.item(), v_min.item()))

        if (epoch + 1) % config['save_freq'] == 0 or epoch == config['epoch_num'] - 1:
            torch.save(net.state_dict(), 'dataset/weight/epoch_{}_model.pt'.format(epoch))
