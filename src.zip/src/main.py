from data_loader import LoadData

if __name__ == '__main__':
    print('hello world')
    data = LoadData()
    data.load_data()
    data.load_json_data()
    # data.out_csv()
    # train_cnn(input_data=data)
