#coding=utf-8

import torch
import numpy as np
from torch.utils.data import DataLoader
from torch.autograd import Variable
import matplotlib.pyplot as plt
import pandas as pd

from data_loader import KFDataset
from models import KFSGNet
from train import config,get_peak_points


def test():
    # 加载模型
    net = KFSGNet()
    net.float().cuda()
    net.eval()  # 测试模式
    if (config['checkout'] != ''):
        net.load_state_dict(torch.load(config['checkout']))

    dataset = KFDataset(config)
    dataset.load_data()
    dataset.load_json_data()
    dataset.load()
    dataLoader = DataLoader(dataset,1)
    all_result = []
    num = len(dataset)
    for i,(images,ids) in enumerate(dataLoader):
        print('{} / {}'.format(i,num))
        images = Variable(images).float().cuda()
        ids = ids.numpy()
        pred_heatmaps = net.forward(images)


        #可视化预测结果
        demo_img = images[0].cpu().data.numpy()[0]
        demo_img = (demo_img * 255.).astype(np.uint8)
        demo_heatmaps = pred_heatmaps[0].cpu().data.numpy()[np.newaxis,...]
        demo_pred_poins = get_peak_points(demo_heatmaps)[0] # (15,2)
        # print(demo_pred_poins[:,0],demo_pred_poins[:,1])
        plt.imshow(demo_img,cmap='gray')
        plt.scatter(demo_pred_poins[:,0],demo_pred_poins[:,1])
        plt.savefig('images/predict/'+str(i)+'.png')
        plt.clf()

        # pred_points = get_peak_points(pred_heatmaps.cpu().data.numpy()) #(N,15,2)
        # pred_points = pred_points.reshape((pred_points.shape[0],-1)) #(N,30)
        

if __name__ == '__main__':
    test()